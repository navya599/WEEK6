import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  employees: Employee[]=[
    {
      id:1,
      name:"kartik",
      email:"rana@gmail.com",
      phone:999
    }
  ];
  constructor() { }

  onGet() {
    return this.employees
  }
}
