import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'sqrt'
})
export class SqrtPipe implements PipeTransform {

  // {{25 | sqrt}}
  // you will get 5
  transform(input_value: number, ...args: unknown[]): number {
    return Math.sqrt(input_value);
  }
}