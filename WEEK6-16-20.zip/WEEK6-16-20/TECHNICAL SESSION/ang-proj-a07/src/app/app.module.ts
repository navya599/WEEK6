import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './component/header/header.component';
import { FooterComponent } from './component/footer/footer.component';
import { HomePageComponent } from './component/home-page/home-page.component';
import { AboutUsComponent } from './component/about-us/about-us.component';
import { ContactUsComponent } from './component/contact-us/contact-us.component';
import { SiteLayoutComponent } from './component/site-layout/site-layout.component';
import { PageNotFoundComponent } from './component/page-not-found/page-not-found.component';
import { ParentComponent } from './component/parent/parent.component';
import { ChildComponent } from './component/child/child.component';
import { SwitchComponent } from './component/switch/switch.component';
import { UserAddComponent } from './component/user-add/user-add.component';
import { HttpClientModule } from '@angular/common/http';
import { Ngclass1Component } from './component/ngclass1/ngclass1.component';
import { Ngclass2Component } from './component/ngclass2/ngclass2.component';
import { Ngclass3Component } from './component/ngclass3/ngclass3.component';
import { Ngclass4Component } from './component/ngclass4/ngclass4.component';
import { NgstyleComponent } from './component/ngstyle/ngstyle.component';
import { UserListComponent } from './component/user-list/user-list.component';
import { UserEditComponent } from './component/user-edit/user-edit.component';
import { TwoWayDataBindingComponent } from './two-way-data-binding/two-way-data-binding.component';
import { HighlightDirective } from './directives/highlight.directive';
import { SqrtPipe } from './pipes/sqrt.pipe';
import { GithubUserDetailsComponent } from './component/github-user-details/github-user-details.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HomePageComponent,
    AboutUsComponent,
    ContactUsComponent,
    SiteLayoutComponent,
    PageNotFoundComponent,
    ParentComponent,
    ChildComponent,
    SwitchComponent,
    UserAddComponent,
    Ngclass1Component,
    Ngclass2Component,
    Ngclass3Component,
    Ngclass4Component,
    NgstyleComponent,
    UserListComponent,
    UserEditComponent,
    TwoWayDataBindingComponent,
    HighlightDirective,
    SqrtPipe,
    GithubUserDetailsComponent,
    
   
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [SiteLayoutComponent]
})
export class AppModule { }
