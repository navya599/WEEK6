import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-user-edit',
  templateUrl: './user-edit.component.html',
  styleUrls: ['./user-edit.component.css']
})
export class UserEditComponent implements OnInit {

  id:any
  user_name:string = ''
  email_id:string = ''
  pass_word:string = ''
  message = ''

  constructor(private route: ActivatedRoute, private router: Router, private http: HttpClient) { }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.id = params['id'];
    })
    this.http.get<any>("http://localhost:5555/user/" + this.id).subscribe(// http://localhost:5555/user/2
      (result) => {
        this.id = result.id;
        this.user_name = result.user_name;
        this.email_id  = result.email_id;
        this.pass_word = result.pass_word;
      }
    )

  }

  editUser() {
    let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded'});
    //let headers = new HttpHeaders({'Content-Type': 'application/json'});

    //let obj = {id:this.id, user_name:this.user_name, email_id:this.email_id, pass_word:this.pass_word}

        var body = "id=" + this.id 
        + "&user_name=" + this.user_name 
        + "&email_id=" + this.email_id 
        + "&pass_word=" + this.pass_word;

    let url = "http://localhost:5555/user/" + this.id

    this.http.put(url, body, {headers:headers, responseType:'text'}).subscribe(
          data => {
            this.router.navigate(['userlist']);
          },
          error => {
            alert(error);
          });
  
    //this.http.put("http://localhost:5555/user/1/", obj, {headers:headers, responseType:'text'});
  }
}