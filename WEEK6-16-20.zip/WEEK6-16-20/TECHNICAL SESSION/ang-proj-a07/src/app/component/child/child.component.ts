import { Component, OnInit, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {

  counter = 0
  @Output() event_emitter1 = new EventEmitter
  constructor() { }

  ngOnInit(): void {
  }

  increment_by1() {
    this.counter += 1
    this.event_emitter1.emit(this.counter)
  }

}