import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-github-user-details',
  templateUrl: './github-user-details.component.html',
  styleUrls: ['./github-user-details.component.css']
})
export class GithubUserDetailsComponent implements OnInit {
  userId:string = ''
  result:any
  error_message:string = ''
  constructor() { }

  ngOnInit(): void {
  }

}
