import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ngclass2',
  templateUrl: './ngclass2.component.html',
  styleUrls: ['./ngclass2.component.css']
})
export class Ngclass2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
