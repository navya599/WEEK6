import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Ngclass1Component } from './ngclass1.component';

describe('Ngclass1Component', () => {
  let component: Ngclass1Component;
  let fixture: ComponentFixture<Ngclass1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Ngclass1Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Ngclass1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
